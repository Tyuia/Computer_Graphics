//Annamaria Dal Bo

var pxDelivery, pzDelivery;
var pxPizza, pyPizza, pzPizza;
var insideArea = false; //default = red, green when the pizza can be delivered
var leavePizza = [false, false, false]; 
var deliveredPizzas = 0; 
var endGame = false;

function throwPizza() {
	if (key[4] && insideArea) { //BAR SPACE clicked
		console.log("pizza da consegnare n. " + (deliveredPizzas+1));
		key[4]=false;
		
		pxPizza = px;
		pyPizza = py;
		pzPizza = pz;
		deliveredPizzas++; //3
		
		if (deliveredPizzas < 3) {
			leavePizza[deliveredPizzas-1] = true;	
			console.log(leavePizza);
			console.log("pizza n. " + (deliveredPizzas) + " consegnata");
			areaInit();
		}
		if (deliveredPizzas == 3) {
			leavePizza[deliveredPizzas-1] = true;
			console.log("pizza n. " + (deliveredPizzas) + " consegnata");
			console.log("fine");
			endGame = true;
			alert("Ottimo lavoro, hai consegnato tutte e tre le pizze!\nOra puoi continuare a gironzolare per la città se vuoi, in attesa dei prossimi ordini.");
		}
		
		let string; 
		if (deliveredPizzas === 1 ) string = "Hai consegnato: " + deliveredPizzas + " pizza su 3.";
		if (deliveredPizzas === 2 ) string = "Hai consegnato: " + deliveredPizzas + " pizze su 3.";
		if (deliveredPizzas === 3 ) string = "Obiettivo raggiunto! Grazie, hai consegnato: " + deliveredPizzas + " pizze su 3.";
		document.getElementById('text').innerHTML = string;
	}
}

function areaInit(){
	
	getRandomPositions();
	
}

function getRandomPositions() {
	
	pxDelivery = getRndInteger(-400, +400);
	pzDelivery = getRndInteger(-400, +400);
	console.log(pxDelivery, pzDelivery);
}